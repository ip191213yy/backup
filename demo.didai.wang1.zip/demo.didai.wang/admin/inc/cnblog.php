<?php


error_reporting(0);
ignore_user_abort(true);
set_time_limit(0);
date_default_timezone_set('PRC');
require 'data.php';
include 'function.php';
include 'key.php';
ini_set('max_execution_time', "0");
require '../QueryList/vendor/autoload.php';
use QL\QueryList;
$links = array();
$page = 'https://news.sina.com.cn/china/';
$reg = array('list' => array('li','html'));
$rang = 'div:hidden';
$ql = QueryList::Query($page, $reg, $rang);
$data = $ql->getData(function($item){
    $item['list'] = QueryList::Query($item['list'],array(
        'item' => array('a','href')
    ))->data;
    return $item;
});
$data = $data[0];
foreach ($data['list'] as $v) {
    echo $v['item'];
}