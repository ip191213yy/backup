<?php
return array (
	'default' => array (
		'hostname' => 'localhost',
		'username' => 'test2com',
		'password' => 'hCficp556j84rSj8',
        'database' => 'test2com',
		)
)
?>