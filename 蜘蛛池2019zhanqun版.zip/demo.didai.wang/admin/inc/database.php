<?php
return array (
	'default' => array (
		'hostname' => 'localhost',
		'username' => 'root',
		'password' => 'root',
        'database' => 'test',
		)
)
?>